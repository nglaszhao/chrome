// ==UserScript==
// @name         百度网盘VIP破解，超大文件直链下载，不限速下载，永久生效    -----   [由于版权问题，暂不支持提取码嗅探啦]
// @namespace    max
// @version      2.2.0.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author       max
// @include      http*://chaoshi.detail.tmall.com/*
// @include      http*://detail.tmall.com/*
// @include      http*://item.taobao.com/*
// @include      http*://list.tmall.com/*
// @include      http*://list.tmall.hk/*
// @include      http*://www.taobao.com/*
// @include      http*://www.tmall.com/*
// @include      http*://s.taobao.com/*
// @include      http*://detail.tmall.hk/*
// @include      http*://chaoshi.tmall.com/*

// @match        https://pan.baidu.com/s/*
// @match        https://pan.baidu.com/share/*
// @match        https://yun.baidu.com/s/*
// @exclude      https://pan.baidu.com/share/manage*
// 
// @grant        GM_openInTab

// ==/UserScript==
