// ==UserScript==
// @name         Youtube自动选择中文翻译字幕
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Youtube自动点击中文翻译字幕
// @author       大奶瓜
// @match        https://www.youtube.com/watch*
// @require      https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function translateToSimpleChinese(){
        var sub = $('[role="menuitem"]:contains("字幕")');
        if(!sub.length) {
            $('.ytp-settings-button').click();
            let btn = $('<button></button>').text('sorry，没有字幕可供翻译').css({"position":"relative","background":"transparent", "top":"-36%","border":"none","color":"rgb(229 229 229)"});
            $('.ytp-right-controls').prepend(btn);
            return
        };
        sub.click();
        var subc = $('[role="menuitemradio"]:contains("中文（简体）")');
        if (subc.length) {
            subc.click();
            $('.ytp-settings-button').click();
        } else {
            var autoTrans = $('[role="menuitemradio"]:contains("自动翻译")');
            if (!autoTrans.length) return;
            autoTrans.click();
            var autoTransC = $('[role="menuitemradio"]:contains("中文（简体）")');
            if (!autoTransC.length) return;
            autoTransC.click();
        }
    }

    function onLoadStart(){
        $('.ytp-subtitles-button[aria-pressed="false"]').click();
        $('.ytp-settings-button').click();
        translateToSimpleChinese();
    }
    $('video').on('loadstart', onLoadStart).trigger('loadstart');
})();

